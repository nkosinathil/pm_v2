/**
 * Chain of Custody JavaScript functions
 * Including signature pad handling for transfers
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded, initializing scripts...");
    
    // =========================
    // SIGNATURE PAD HANDLING
    // =========================
    
    // Global signature pad objects
    window.releasedSignaturePad = null;
    window.receivedSignaturePad = null;
    window.transferReleaserSignaturePad = null;
    window.transferRecipientSignaturePad = null;
    
    // Initialize main signature pads
    function initializeSignaturePads() {
        // Main form signature pads
        if (document.getElementById('released-signature-pad')) {
            window.releasedSignaturePad = new SignaturePad(document.getElementById('released-signature-pad'), {
                backgroundColor: 'rgba(255, 255, 255, 0)',
                penColor: 'black'
            });
            
            // Add clear button event listener
            document.getElementById('clear-released-signature').addEventListener('click', function() {
                window.releasedSignaturePad.clear();
                document.getElementById('released_signature_data').value = '';
            });
        }
        
        if (document.getElementById('received-signature-pad')) {
            window.receivedSignaturePad = new SignaturePad(document.getElementById('received-signature-pad'), {
                backgroundColor: 'rgba(255, 255, 255, 0)',
                penColor: 'black'
            });
            
            // Add clear button event listener
            document.getElementById('clear-received-signature').addEventListener('click', function() {
                window.receivedSignaturePad.clear();
                document.getElementById('received_signature_data').value = '';
            });
        }
    }
    
    // Initialize transfer signature pads
    function initializeTransferSignaturePads() {
        console.log("Initializing transfer signature pads");
        
        if (document.getElementById('transfer-releaser-signature-pad')) {
            window.transferReleaserSignaturePad = new SignaturePad(document.getElementById('transfer-releaser-signature-pad'), {
                backgroundColor: 'rgba(255, 255, 255, 0)',
                penColor: 'black'
            });
            console.log("Releaser signature pad initialized");
            
            // Resize canvas
            resizeSignatureCanvas('transfer-releaser-signature-pad');
            
            // Add clear button event listener
            document.getElementById('clear-transfer-releaser-signature').addEventListener('click', function() {
                window.transferReleaserSignaturePad.clear();
            });
        }
        
        if (document.getElementById('transfer-recipient-signature-pad')) {
            window.transferRecipientSignaturePad = new SignaturePad(document.getElementById('transfer-recipient-signature-pad'), {
                backgroundColor: 'rgba(255, 255, 255, 0)',
                penColor: 'black'
            });
            console.log("Recipient signature pad initialized");
            
            // Resize canvas
            resizeSignatureCanvas('transfer-recipient-signature-pad');
            
            // Add clear button event listener
            document.getElementById('clear-transfer-recipient-signature').addEventListener('click', function() {
                window.transferRecipientSignaturePad.clear();
            });
        }
    }
    
    // Make signature pads responsive
    function resizeSignatureCanvas(canvasId) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        canvas.getContext("2d").scale(ratio, ratio);
    }
    
    // =========================
    // TRANSFER MODAL HANDLING
    // =========================
    
    // Setup transfer modal opening
   function setupTransferModal() {
    const addTransferBtn = document.getElementById('addTransferBtn');
    
    if (addTransferBtn) {
        console.log("Setting up transfer button for redirect");
        
        // Update the button to redirect to the custody_transfer_form.php page
        addTransferBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the custody ID from the current page URL
            const urlParams = new URLSearchParams(window.location.search);
            const custody_id = urlParams.get('id');
            const job_code = document.getElementById('job_code') ? 
                document.getElementById('job_code').value : '';
                
            // Redirect to the transfer form with custody ID and job code as parameters
            window.location.href = `custody_transfer_form.php?custody_id=${custody_id}&job_code=${job_code}`;
        });
    }
}
    
    // Setup form submission with signature capture - THIS HANDLES THE FIX FOR SIGNATURES
    function setupTransferFormValidation() {
        const addTransferForm = document.getElementById('addTransferForm');
        
        if (addTransferForm) {
            console.log("Setting up transfer form submission handler");
            
            // Override default form submission to properly handle signatures
            addTransferForm.addEventListener('submit', function(e) {
                e.preventDefault(); // Prevent default submission
                console.log("Transfer form submission intercepted");
                
                // Validate required fields
                let valid = validateFormFields(this);
                
                // Capture signatures if valid
                if (valid) {
                    valid = captureSignatures();
                }
                
                // Submit if everything is valid
                if (valid) {
                    console.log("Form validation passed, submitting");
                    this.submit();
                }
            });
        }
    }
    
    // Validate required form fields
    function validateFormFields(form) {
        let valid = true;
        const requiredFields = form.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                valid = false;
                alert('Please fill in field: ' + field.name);
                field.classList.add('error');
            } else {
                field.classList.remove('error');
            }
        });
        
        return valid;
    }
    
    // Capture signatures from pads - THIS IS THE CRITICAL PART FOR THE FIX
/**
 * Modified captureSignatures function for coc-script.js
 * This should replace the existing function in your file
 */
// Replace the captureSignatures function with this debug version
function captureSignatures() {
    console.log("DEBUG: captureSignatures() called");
    
    // Get the hidden signature input fields
    const releaserField = document.getElementById('transfer_releaser_signature');
    const recipientField = document.getElementById('transfer_recipient_signature');
    
    console.log("DEBUG: Hidden fields found:", 
                "releaser field exists:", !!releaserField, 
                "recipient field exists:", !!recipientField);
    
    // Check signature pads
    if (!window.transferReleaserSignaturePad) {
        console.error("DEBUG: transferReleaserSignaturePad is not initialized");
        alert('Signature pad not initialized. Please refresh and try again.');
        return false;
    }
    
    if (!window.transferRecipientSignaturePad) {
        console.error("DEBUG: transferRecipientSignaturePad is not initialized");
        alert('Signature pad not initialized. Please refresh and try again.');
        return false;
    }
    
    console.log("DEBUG: Signature pads initialized:", 
                "releaser empty:", window.transferReleaserSignaturePad.isEmpty(),
                "recipient empty:", window.transferRecipientSignaturePad.isEmpty());
    
    // Check if signatures are empty
    if (window.transferReleaserSignaturePad.isEmpty()) {
        alert('Please provide the releaser signature');
        return false;
    }
    
    if (window.transferRecipientSignaturePad.isEmpty()) {
        alert('Please provide the recipient signature');
        return false;
    }
    
    // Get signature data as PNG
    const releaserSignature = window.transferReleaserSignaturePad.toDataURL('image/png');
    const recipientSignature = window.transferRecipientSignaturePad.toDataURL('image/png');
    
    console.log("DEBUG: Signatures captured successfully");
    console.log("DEBUG: Releaser signature length:", releaserSignature.length);
    console.log("DEBUG: Recipient signature length:", recipientSignature.length);
    
    // Output the first part of each signature for verification
    console.log("DEBUG: Releaser signature starts with:", releaserSignature.substring(0, 50) + "...");
    console.log("DEBUG: Recipient signature starts with:", recipientSignature.substring(0, 50) + "...");
    
    // Set the form field values
    if (releaserField) {
        releaserField.value = releaserSignature;
        console.log("DEBUG: Set releaser field value, new length:", releaserField.value.length);
    } else {
        console.error("DEBUG: Cannot set releaser signature - field not found!");
        
        // Create field if missing
        const newReleaserField = document.createElement('input');
        newReleaserField.type = 'hidden';
        newReleaserField.id = 'transfer_releaser_signature';
        newReleaserField.name = 'transfer_releaser_signature';
        newReleaserField.value = releaserSignature;
        document.getElementById('addTransferForm').appendChild(newReleaserField);
        console.log("DEBUG: Created missing releaser signature field");
    }
    
    if (recipientField) {
        recipientField.value = recipientSignature;
        console.log("DEBUG: Set recipient field value, new length:", recipientField.value.length);
    } else {
        console.error("DEBUG: Cannot set recipient signature - field not found!");
        
        // Create field if missing
        const newRecipientField = document.createElement('input');
        newRecipientField.type = 'hidden';
        newRecipientField.id = 'transfer_recipient_signature';
        newRecipientField.name = 'transfer_recipient_signature';
        newRecipientField.value = recipientSignature;
        document.getElementById('addTransferForm').appendChild(newRecipientField);
        console.log("DEBUG: Created missing recipient signature field");
    }
    
    // Verify the form contains the signature data right before submission
    console.log("DEBUG: Form fields right before submission:");
    const formData = new FormData(document.getElementById('addTransferForm'));
    let hasReleaserSignature = false;
    let hasRecipientSignature = false;
    
    for (let [key, value] of formData.entries()) {
        if (key === 'transfer_releaser_signature') {
            hasReleaserSignature = true;
            console.log(`DEBUG: ${key} is present in form data with length ${value.length}`);
        }
        else if (key === 'transfer_recipient_signature') {
            hasRecipientSignature = true;
            console.log(`DEBUG: ${key} is present in form data with length ${value.length}`);
        }
        else {
            console.log(`DEBUG: ${key}: ${value}`);
        }
    }
    
    console.log("DEBUG: Form contains releaser signature:", hasReleaserSignature);
    console.log("DEBUG: Form contains recipient signature:", hasRecipientSignature);
    
    return true;
}
    
    // =========================
    // DEVICE MANAGEMENT
    // =========================
    
    function setupDeviceManagement() {
        // Add new device
        const addDeviceBtn = document.getElementById('addDevice');
        const newDevicesContainer = document.getElementById('newDevices');
        let newDeviceCount = 0;
        
        if (addDeviceBtn && newDevicesContainer) {
            addDeviceBtn.addEventListener('click', function() {
                newDeviceCount++;
                const deviceElement = document.createElement('div');
                deviceElement.className = 'device-entry';
                deviceElement.innerHTML = `
                    <div class="device-header">
                        <h3>New Device #${newDeviceCount}</h3>
                        <button type="button" class="remove-new-device" title="Remove device"><i class="fas fa-trash"></i></button>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Device Type</label>
                            <select name="new_device_type[]" required>
                                <option value="">Select Type</option>
                                <option value="Computer">Computer</option>
                                <option value="Laptop">Laptop</option>
                                <option value="Server">Server</option>
                                <option value="Mobile Phone">Mobile Phone</option>
                                <option value="Tablet">Tablet</option>
                                <option value="Hard Drive">Hard Drive</option>
                                <option value="USB Drive">USB Drive</option>
                                <option value="Memory Card">Memory Card</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Make</label>
                            <input type="text" name="new_make[]" placeholder="e.g. Apple, Dell, Samsung">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Model</label>
                            <input type="text" name="new_model[]" placeholder="e.g. MacBook Pro, Inspiron">
                        </div>
                        <div class="form-group">
                            <label>Serial Number</label>
                            <input type="text" name="new_serial_number[]" placeholder="Serial/IMEI Number" required>
                        </div>
                    </div>
                `;
                
                newDevicesContainer.appendChild(deviceElement);
                
                // Attach remove event
                deviceElement.querySelector('.remove-new-device').addEventListener('click', function() {
                    deviceElement.remove();
                    updateNewDeviceNumbers();
                });
            });
        }
        
        // Remove new device
        document.addEventListener('click', function(e) {
            if (e.target.closest('.remove-new-device')) {
                const deviceEntry = e.target.closest('.device-entry');
                deviceEntry.remove();
                updateNewDeviceNumbers();
            }
        });
        
        // Update new device numbers
        function updateNewDeviceNumbers() {
            if (!newDevicesContainer) return;
            
            const deviceEntries = newDevicesContainer.querySelectorAll('.device-entry');
            deviceEntries.forEach((entry, index) => {
                const header = entry.querySelector('h3');
                if (header) {
                    header.textContent = `New Device #${index + 1}`;
                }
            });
            newDeviceCount = deviceEntries.length;
        }
        
        // Delete device modal
        const deleteDeviceModal = document.getElementById('deleteDeviceModal');
        const deleteDeviceId = document.getElementById('delete_device_id');
        const cancelDeleteBtn = document.getElementById('cancelDelete');
        const closeBtn = document.querySelector('.close');
        
        // Show delete modal when remove button is clicked
        document.querySelectorAll('.remove-device-btn').forEach(button => {
            button.addEventListener('click', function() {
                deleteDeviceId.value = this.getAttribute('data-id');
                deleteDeviceModal.style.display = 'block';
            });
        });
        
        // Close delete modal
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                deleteDeviceModal.style.display = 'none';
            });
        }
        
        if (cancelDeleteBtn) {
            cancelDeleteBtn.addEventListener('click', function() {
                deleteDeviceModal.style.display = 'none';
            });
        }
    }
    
    // =========================
    // RETURN MODAL HANDLING
    // =========================
    
    function setupReturnModal() {
        const markReturnedBtn = document.getElementById('markReturnedBtn');
        const returnModal = document.getElementById('returnModal');
        const cancelReturnBtns = document.querySelectorAll('.cancel-return, .close-return');
        
        if (markReturnedBtn && returnModal) {
            markReturnedBtn.addEventListener('click', function() {
                returnModal.style.display = 'block';
            });
        }
        
        // Cancel return modal
        cancelReturnBtns.forEach(btn => {
            if (btn) {
                btn.addEventListener('click', function() {
                    returnModal.style.display = 'none';
                });
            }
        });
    }
    
    // =========================
    // VIEW TRANSFER DETAILS
    // =========================
    
    function setupViewTransferDetails() {
        const viewTransferModal = document.getElementById('viewTransferModal');
        const viewTransferClose = document.querySelector('.view-transfer-close');
        
        document.querySelectorAll('.view-transfer').forEach(button => {
            button.addEventListener('click', function() {
                const transferId = this.getAttribute('data-id');
                console.log("Viewing transfer ID:", transferId);
                
                // AJAX request to get transfer details
                fetch(`get-transfer-details.php?id=${transferId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const transfer = data.transfer;
                            const details = document.getElementById('transferDetails');
                            
                            console.log("Transfer data:", transfer);
                            
                            let html = `
                                <div class="transfer-detail">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label>Date & Time</label>
                                            <input type="text" value="${formatDate(transfer.transfer_date)}" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Purpose</label>
                                            <input type="text" value="${transfer.transfer_reason}" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="transfer-section">
                                        <h4><i class="fas fa-arrow-right"></i> Released By (Current Custodian)</h4>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Full Name</label>
                                                <input type="text" value="${transfer.released_by_name}" readonly>
                                            </div>
                                            <div class="form-group">
                                                <label>Position</label>
                                                <input type="text" value="${transfer.released_by_position}" readonly>
                                            </div>
                                        </div>
                                        ${transfer.releaser_signature ? `
                                            <div class="form-group full-width">
                                                <label>Releaser Signature</label>
                                                <div class="signature-image">
                                                    <img src="${transfer.releaser_signature}" alt="Releaser Signature">
                                                </div>
                                            </div>
                                        ` : '<p>No releaser signature available</p>'}
                                    </div>
                                    
                                    <div class="transfer-section">
                                        <h4><i class="fas fa-arrow-left"></i> Received By (New Custodian)</h4>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Full Name</label>
                                                <input type="text" value="${transfer.received_by_name}" readonly>
                                            </div>
                                            <div class="form-group">
                                                <label>Position</label>
                                                <input type="text" value="${transfer.received_by_position}" readonly>
                                            </div>
                                        </div>
                                        ${transfer.recipient_signature ? `
                                            <div class="form-group full-width">
                                                <label>Recipient Signature</label>
                                                <div class="signature-image">
                                                    <img src="${transfer.recipient_signature}" alt="Recipient Signature">
                                                </div>
                                            </div>
                                        ` : '<p>No recipient signature available</p>'}
                                    </div>
                                    
                                    <div class="form-actions">
                                        <button type="button" class="action-button close-view-transfer">Close</button>
                                    </div>
                                </div>
                            `;
                            
                            details.innerHTML = html;
                            
                            // Add close event for the view transfer modal
                            document.querySelector('.close-view-transfer')?.addEventListener('click', function() {
                                viewTransferModal.style.display = 'none';
                            });
                            
                            viewTransferModal.style.display = 'block';
                        } else {
                            alert('Failed to load transfer details');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while loading transfer details');
                    });
            });
        });
        
        // Close view transfer modal
        if (viewTransferClose) {
            viewTransferClose.addEventListener('click', function() {
                viewTransferModal.style.display = 'none';
            });
        }
    }
    
    // =========================
    // DELETE TRANSFER HANDLING
    // =========================
    
    function setupDeleteTransfer() {
        // Delete transfer
        document.querySelectorAll('.delete-transfer').forEach(button => {
            button.addEventListener('click', function() {
                const transferId = this.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this transfer record? This action cannot be undone.')) {
                    const urlParams = new URLSearchParams(window.location.search);
                    const custody_id = urlParams.get('id');
                    window.location.href = `delete-transfer.php?id=${transferId}&custody_id=${custody_id}`;
                }
            });
        });
    }
    
    // =========================
    // MAIN FORM VALIDATION
    // =========================
    
    function setupMainFormValidation() {
        const cocForm = document.getElementById('cocForm');
        
        if (cocForm) {
            cocForm.addEventListener('submit', function(e) {
                let valid = true;
                
                // Check if signatures are added and store them
                if (window.releasedSignaturePad && !window.releasedSignaturePad.isEmpty()) {
                    document.getElementById('released_signature_data').value = window.releasedSignaturePad.toDataURL();
                }
                
                if (window.receivedSignaturePad && !window.receivedSignaturePad.isEmpty()) {
                    document.getElementById('received_signature_data').value = window.receivedSignaturePad.toDataURL();
                }
                
                // Check required fields
                const requiredFields = cocForm.querySelectorAll('[required]');
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        valid = false;
                        field.classList.add('error');
                        
                        // Add error message if it doesn't exist
                        const errorMsg = field.nextElementSibling;
                        if (!errorMsg || !errorMsg.classList.contains('error-message')) {
                            const msg = document.createElement('div');
                            msg.className = 'error-message';
                            msg.textContent = 'This field is required';
                            field.parentNode.insertBefore(msg, field.nextSibling);
                        }
                    } else {
                        field.classList.remove('error');
                        const errorMsg = field.nextElementSibling;
                        if (errorMsg && errorMsg.classList.contains('error-message')) {
                            errorMsg.remove();
                        }
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                    alert('Please fill in all required fields.');
                    return false;
                }
                
                return true;
            });
        }
        
        // Remove error styling on input
        document.addEventListener('input', function(e) {
            if (e.target.hasAttribute('required')) {
                e.target.classList.remove('error');
                const errorMsg = e.target.nextElementSibling;
                if (errorMsg && errorMsg.classList.contains('error-message')) {
                    errorMsg.remove();
                }
            }
        });
    }
    
    // =========================
    // MODAL HANDLING
    // =========================
    
    function setupModalClosing() {
        // Close modals when clicking outside
        window.addEventListener('click', function(event) {
            const deleteDeviceModal = document.getElementById('deleteDeviceModal');
            const addTransferModal = document.getElementById('addTransferModal');
            const returnModal = document.getElementById('returnModal');
            const viewTransferModal = document.getElementById('viewTransferModal');
            
            if (event.target === deleteDeviceModal) {
                deleteDeviceModal.style.display = 'none';
            }
            if (event.target === addTransferModal) {
                addTransferModal.style.display = 'none';
            }
            if (event.target === returnModal) {
                returnModal.style.display = 'none';
            }
            if (event.target === viewTransferModal) {
                viewTransferModal.style.display = 'none';
            }
        });
    }
    
    // =========================
    // MOBILE MENU
    // =========================
    
    function setupMobileMenu() {
        const mobileToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.querySelector('.sidebar');
        
        if (mobileToggle) {
            mobileToggle.addEventListener('click', function() {
                sidebar.classList.toggle('active');
            });
        }
    }
    
    // =========================
    // UTILITY FUNCTIONS
    // =========================
    
    // Format date helper
    function formatDate(dateString) {
        if (!dateString) return '';
        
        const date = new Date(dateString);
        if (isNaN(date)) return dateString;
        
        return date.toLocaleString('en-GB', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    // =========================
    // INITIALIZE ALL FUNCTIONS
    // =========================
    
    try {
        // Initialize all functionality
        initializeSignaturePads();
        setupTransferModal();
        setupTransferFormValidation();
        setupDeviceManagement();
        setupReturnModal();
        setupViewTransferDetails();
        setupDeleteTransfer();
        setupMainFormValidation();
        setupModalClosing();
        setupMobileMenu();
        
        console.log("Script initialization complete");
    } catch (e) {
        console.error("Error during script initialization:", e);
    }
});